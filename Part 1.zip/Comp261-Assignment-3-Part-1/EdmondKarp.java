
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.HashMap;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Map;
import javafx.util.Pair;

/** Edmond karp algorithm to find augmentation paths and network flow.
 * 
 * This would include building the supporting data structures:
 * 
 * a) Building the residual graph(that includes original and backward (reverse) edges.)
 *     - maintain a map of Edges where for every edge in the original graph we add a reverse edge in the residual graph.
 *     - The map of edges are set to include original edges at even indices and reverse edges at odd indices (this helps accessing the corresponding backward edge easily)
 *     
 *     
 * b) Using this residual graph, for each city maintain a list of edges out of the city (this helps accessing the neighbours of a node (both original and reverse))

 * The class finds : augmentation paths, their corresponing flows and the total flow
 * 
 * 
 */

public class EdmondKarp {
    // class members

    //data structure to maintain a list of forward and reverse edges - forward edges stored at even indices and reverse edges stored at odd indices
    private static Map<String,Edge> edges; 

    // Augmentation path and the corresponding flow
    private static ArrayList<Pair<ArrayList<String>, Integer>> augmentationPaths =null;

    
    //TODO:Build the residual graph that includes original and reverse edges 
    public static void computeResidualGraph(Graph graph){
        // TODO
        int count = 0;
        edges = new HashMap<>();
        for (Edge edge : graph.getOriginalEdges()) {
            //forward
            edges.put(String.valueOf(count), new Edge(edge.fromCity(), edge.toCity(), edge.capacity(), edge.flow()));
            edge.fromCity().addEdgeId(String.valueOf(count));
            count++;
            //reverse
            edges.put(String.valueOf(count), new Edge(edge.toCity(), edge.fromCity(), 0, 0));
            edge.toCity().addEdgeId(String.valueOf(count));
            count++;
        }
        //printResidualGraphData(graph);  //may help in debugging
        // END TODO
    }

    // Method to print Residual Graph 
    public static void printResidualGraphData(Graph graph){
        System.out.println("\nResidual Graph");
        System.out.println("\n=============================\nCities:");
        for (City city : graph.getCities().values()){
            System.out.print(city.toString());

            // for each city display the out edges 
            for(String eId: city.getEdgeIds()){
                System.out.print("["+eId+"] ");
            }
            System.out.println();
        }
        System.out.println("\n=============================\nEdges(Original(with even Id) and Reverse(with odd Id):");
        edges.forEach((eId, edge)->
                System.out.println("["+eId+"] " +edge.toString()));

        System.out.println("===============");
    }

    //=============================================================================
    //  Methods to access data from the graph. 
    //=============================================================================
    /**
     * Return the corresonding edge for a given key
     */

    public static Edge getEdge(String id){
        return edges.get(id);
    }

    /** find maximum flow
     * 
     */
    // TODO: Find augmentation paths and their corresponding flows
    public static ArrayList<Pair<ArrayList<String>, Integer>> calcMaxflows(Graph graph, City from, City to) {
        //TODO
        computeResidualGraph(graph);
        augmentationPaths = new ArrayList<>();
        while (true) {
            Pair<ArrayList<String>, Integer> augmentationPath = bfs(graph, from, to);
            if (augmentationPath.equals(new Pair(null,0))) {
                if (!augmentationPaths.isEmpty()) {
                    return augmentationPaths;
                } else {
                    return null;
                }
            }
            augmentationPaths.add(augmentationPath);
            for (String eID : augmentationPath.getKey()) {
                Edge e = edges.get(eID);
                e.setFlow(e.flow() + augmentationPath.getValue());
                e.setCapacity(e.capacity() - augmentationPath.getValue());
                Edge reverseE = edges.get(String.valueOf(Integer.parseInt(eID) + 1));
                reverseE.setCapacity(reverseE.capacity() + augmentationPath.getValue());
            }
        }
        // END TODO
    }

    // TODO:Use BFS to find a path from s to t along with the correponding bottleneck flow
    public static Pair<ArrayList<String>, Integer>  bfs(Graph graph, City s, City t) {
        ArrayList<String> augmentationPath = new ArrayList<String>();
        HashMap<String, String> backPointer = new HashMap<String, String>();
        // TODO
        Queue<City> queue = new ArrayDeque<>();
        queue.add(s);
        while (!queue.isEmpty()) {
            City cur = queue.poll();
            for (String eID : cur.getEdgeIds()) {
                Edge e = edges.get(eID);
                if (e.toCity() != s && backPointer.get(e.toCity().toString()) == null && e.capacity() != 0) {
                    backPointer.put(e.toCity().toString(), eID);
                    if (backPointer.containsKey(t.toString())) {
                        String pathEdge = backPointer.get(t.toString());
                        while (pathEdge != null) {
                            augmentationPath.add(pathEdge);
                            pathEdge = backPointer.getOrDefault(edges.get(pathEdge).fromCity().toString(), null);
                        }
                        Collections.reverse(augmentationPath);
                        return new Pair<>(augmentationPath, bottleneck(augmentationPath));
                    }
                    queue.add(e.toCity());
                }
            }
        }
        // END TODO
        return new Pair(null,0);
    }

    public static int bottleneck(ArrayList<String> augmentationPath) {
        if (augmentationPath.isEmpty()) {
            return 0;
        }
        int bottleneck = edges.get(augmentationPath.get(0)).capacity();
        for (String str : augmentationPath) {
            if (edges.get(str).capacity() < bottleneck) {
                bottleneck = edges.get(str).capacity();
            }
        }
        return bottleneck;
    }
   
}


