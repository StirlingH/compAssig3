import javafx.util.Pair;

import java.util.*;
import java.util.stream.Collectors;

/**
* Write a description of class PageRank here.
*
* @author (your name)
* @version (a version number or a date)
*/
public class PageRank
{
    //class members 
    private static double dampingFactor = .85;
    private static int iter = 10;
    /**
    * build the fromLinks and toLinks 
    */
    //TODO: Build the data structure to support Page rank. Compute the fromLinks and toLinks for each node
    public static void computeLinks(Graph graph){
        // TODO
        for (Edge edge : graph.getOriginalEdges()) {
            edge.fromNode().addToLinks(edge.toNode());
            edge.toNode().addFromLinks(edge.fromNode());
        }
        //printPageRankGraphData(graph);  ////may help in debugging
        // END TODO
    }

    public static void printPageRankGraphData(Graph graph){
        System.out.println("\nPage Rank Graph");

        for (Gnode node : graph.getNodes().values()){
            System.out.print("\nNode: "+node.toString());
            //for each node display the in edges 
            System.out.print("\nIn links to nodes:");
            for(Gnode c:node.getFromLinks()){

                System.out.print("["+c.getId()+"] ");
            }

            System.out.print("\nOut links to nodes:");
            //for each node display the out edges 
            for(Gnode c: node.getToLinks()){
                System.out.print("["+c.getId()+"] ");
            }
            System.out.println();;

        }    
        System.out.println("=================");
    }
    //TODO: Compute rank of all nodes in the network and display them at the console
    public static void computePageRank(Graph graph){
        // TODO
        double nNodes = graph.getNodes().size();
        Map<Gnode, Double> pageranks = new TreeMap<>();
        Map<Gnode, Double> newPageranks = new TreeMap<>();
        for (Gnode n : graph.getNodes().values()) {
            pageranks.put(n, 1/nNodes);
            newPageranks.put(n, 0.0);
        }
        int count = 1;
        while (count <= iter) {
            double noOutLinkShare = 0.0;
            for (Gnode n : pageranks.keySet()) {
                if (n.getToLinks().isEmpty()) {
                    noOutLinkShare += dampingFactor * (pageranks.get(n) / nNodes);
                }
            }
            for (Gnode n : pageranks.keySet()) {
                double nRank = noOutLinkShare + (1 - dampingFactor) / nNodes;
                double neighboursShare = 0.0;
                for (Gnode b : n.getFromLinks()) {
                    neighboursShare += pageranks.get(b) / b.getToLinks().size();
                }
                newPageranks.put(n, nRank + dampingFactor * neighboursShare);
            }
            pageranks.putAll(newPageranks);
            count++;
        }
        System.out.println("Iteration 10:\n");
        for (Gnode n : pageranks.keySet()) {
            System.out.println(n.getName() + "[" + n.getId() + "]: " + pageranks.get(n));
        }
        // END TODO
    }

    public static Map<Gnode, Double> otherPageRank(Graph graph){
        // TODO
        double nNodes = graph.getNodes().size();
        Map<Gnode, Double> pageranks = new TreeMap<>();
        Map<Gnode, Double> newPageranks = new TreeMap<>();
        for (Gnode n : graph.getNodes().values()) {
            pageranks.put(n, 1/nNodes);
            newPageranks.put(n, 0.0);
        }
        int count = 1;
        while (count <= iter) {
            double noOutLinkShare = 0.0;
            for (Gnode n : pageranks.keySet()) {
                if (n.getToLinks().isEmpty()) {
                    noOutLinkShare += dampingFactor * (pageranks.get(n) / nNodes);
                }
            }
            for (Gnode n : pageranks.keySet()) {
                double nRank = noOutLinkShare + (1 - dampingFactor) / nNodes;
                double neighboursShare = 0.0;
                for (Gnode b : n.getFromLinks()) {
                    neighboursShare += pageranks.get(b) / b.getToLinks().size();
                }
                newPageranks.put(n, nRank + dampingFactor * neighboursShare);
            }
            pageranks.putAll(newPageranks);
            count++;
        }
        return pageranks;
        // END TODO
    }
    
    public static void computeMostImpneighbour(Graph graph){
    // TODO
        for (Gnode n : graph.getNodes().values()) {
            Gnode mostImp = null;
            Double rank = null;
            if (n.getFromLinks().isEmpty()) {
                System.out.println("Node " + n + " has no inlinks");
            } else {
                for (Gnode inN : n.getFromLinks()) {
                    Map<String, Gnode> freshNodes = graph.getNodes().values().stream()
                            .map(node -> new Gnode(node.getPoint().getX(), node.getPoint().getY(), node.getName(), node.getId()))
                            .collect(Collectors.toMap(Gnode::getName, no -> no));
                    Map<String,Gnode> map = new TreeMap<>(freshNodes);
                    map.values().remove(inN);
                    Collection<Edge> edges = new HashSet<>(graph.getOriginalEdges());
                    edges.removeIf(e -> e.fromNode() == inN || e.toNode() == inN);
                    Graph g = new Graph(map, edges);
                    computeLinks(g);
                    Map<Gnode,Double> ranks = otherPageRank(g);
                    if (mostImp == null) {
                        mostImp = inN;
                        rank = ranks.get(n);
                    } else if (ranks.get(n) < rank) {
                        mostImp = inN;
                        rank = ranks.get(n);
                    }
                }
                System.out.println("Node " + n.getName() + ": " + mostImp.getName());
            }

        }
    // END TODO
    }
    
    
}
